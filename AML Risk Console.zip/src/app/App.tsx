import { useState, useCallback } from 'react';
import { LoginPage } from './components/LoginPage';
import { Header } from './components/Header';
import { NetworkGraph } from './components/NetworkGraph';
import { RiskPanel } from './components/RiskPanel';
import { ChatWindow } from './components/ChatWindow';
import { AMLCase } from './data/cases';
import {
  CaseProgress,
  loadCaseProgress,
  saveCaseProgress,
  defaultProgress,
  addFinding,
  saveUser,
  loadUser,
  ChatMessage,
} from './hooks/useCaseStorage';

interface AuthState {
  userId: string;
  userName: string;
  userRole: string;
}

export default function App() {
  const [auth, setAuth] = useState<AuthState | null>(() => {
    const saved = loadUser();
    return saved ? { userId: saved, userName: `Analyst ${saved}`, userRole: 'AML Analyst' } : null;
  });

  const [selectedCase, setSelectedCase] = useState<AMLCase | null>(null);
  const [progress, setProgress] = useState<CaseProgress | null>(null);

  const handleLogin = (userId: string, name: string, role: string) => {
    saveUser(userId);
    setAuth({ userId, userName: name, userRole: role });
  };

  const handleLogout = () => {
    setAuth(null);
    setSelectedCase(null);
    setProgress(null);
  };

  const handleCaseSelect = useCallback((c: AMLCase) => {
    setSelectedCase(c);

    const saved = loadCaseProgress(c.id);
    if (saved) {
      // Resume — add a resume entry
      const resumed = addFinding(saved, 'case_resumed', `Case resumed by ${auth?.userName ?? 'analyst'}.`);
      setProgress(resumed);
      saveCaseProgress(resumed);
    } else {
      const fresh = defaultProgress(c.id);
      setProgress(fresh);
      saveCaseProgress(fresh);
    }
  }, [auth]);

  const handleProgressChange = useCallback((p: CaseProgress) => {
    setProgress(p);
    saveCaseProgress(p);
  }, []);

  const handlePositionsChange = useCallback((positions: Record<string, { x: number; y: number }>) => {
    if (!progress) return;
    const next = { ...progress, nodePositions: positions };
    setProgress(next);
    saveCaseProgress(next);
  }, [progress]);

  const handleChatMessages = useCallback((msgs: ChatMessage[]) => {
    if (!progress) return;
    const next = { ...progress, chatHistory: msgs };
    setProgress(next);
    saveCaseProgress(next);
  }, [progress]);

  if (!auth) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="h-screen flex flex-col bg-gray-50 overflow-hidden">
      <Header
        userId={auth.userId}
        userName={auth.userName}
        userRole={auth.userRole}
        selectedCaseId={selectedCase?.id ?? null}
        onCaseSelect={handleCaseSelect}
        onLogout={handleLogout}
      />

      <div className="flex flex-1 overflow-hidden">
        {selectedCase ? (
          <NetworkGraph
            key={selectedCase.id}
            initialNodes={selectedCase.nodes}
            edges={selectedCase.edges}
            savedPositions={progress?.nodePositions}
            onNodeSelect={() => {}}
            onPositionsChange={handlePositionsChange}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center bg-[#e8eaed]">
            <div className="text-center">
              <div className="w-16 h-16 rounded-2xl bg-white/70 border border-gray-200 flex items-center justify-center mx-auto mb-4 shadow-sm">
                <div className="w-7 h-7 border-2 border-slate-300 rounded" />
              </div>
              <p className="text-slate-500 text-sm font-medium mb-1">No network loaded</p>
              <p className="text-slate-400 text-xs">Select an alerted customer from the dropdown above</p>
            </div>
          </div>
        )}

        <RiskPanel
          amlCase={selectedCase}
          progress={progress}
          onProgressChange={handleProgressChange}
        />
      </div>

      <ChatWindow
        amlCase={selectedCase}
        history={progress?.chatHistory ?? []}
        onNewMessages={handleChatMessages}
      />
    </div>
  );
}
