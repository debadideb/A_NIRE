import { useState } from 'react';
import { FileText, ArrowUpCircle, CheckCircle, Clock, User, Cpu, ChevronDown, Download } from 'lucide-react';
import { AMLCase, RiskCategory } from '../data/cases';
import { CaseProgress, addFinding, saveCaseProgress, exportLog } from '../hooks/useCaseStorage';

const FACTOR_COLORS: Record<RiskCategory, { dot: string; badge: string; text: string }> = {
  circular:   { dot: 'bg-orange-400', badge: 'bg-orange-50 border-orange-200 text-orange-700',  text: 'text-orange-700' },
  sanctioned: { dot: 'bg-red-500',    badge: 'bg-red-50 border-red-200 text-red-700',            text: 'text-red-700'   },
  shell:      { dot: 'bg-orange-400', badge: 'bg-amber-50 border-amber-200 text-amber-700',       text: 'text-amber-700' },
};

interface Props {
  amlCase: AMLCase | null;
  progress: CaseProgress | null;
  onProgressChange: (p: CaseProgress) => void;
}

export function RiskPanel({ amlCase, progress, onProgressChange }: Props) {
  const [expandedFactors, setExpandedFactors] = useState<Set<number>>(new Set());
  const [activeTab, setActiveTab] = useState<'sar' | 'trail'>('sar');

  if (!amlCase || !progress) {
    return (
      <div className="w-[380px] flex-shrink-0 flex flex-col items-center justify-center bg-white border-l border-gray-200 text-center px-8">
        <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center mb-3">
          <FileText size={20} className="text-gray-400" />
        </div>
        <p className="text-sm font-medium text-gray-600 mb-1">No case selected</p>
        <p className="text-xs text-gray-400">Select an alerted customer from the dropdown to load the risk analysis.</p>
      </div>
    );
  }

  const { riskScore, riskFactors, sarSummary, customerName, id: caseId } = amlCase;
  const decision = progress.decision;
  const notes = progress.notes;

  const toggleFactor = (i: number) => {
    setExpandedFactors(prev => {
      const next = new Set(prev);
      next.has(i) ? next.delete(i) : next.add(i);
      return next;
    });
  };

  const update = (patch: Partial<CaseProgress>) => {
    const next = { ...progress, ...patch };
    onProgressChange(next);
    saveCaseProgress(next);
  };

  const handleDecision = (type: 'filed' | 'cleared' | 'escalated') => {
    const labels = { filed: 'SAR filed', cleared: 'Case cleared', escalated: 'Escalated to senior analyst' };
    const next = addFinding(progress, 'decision', `Decision recorded: ${labels[type]}.`);
    update({ ...next, decision: type });
  };

  const handleNotesBlur = () => {
    if (notes) {
      const next = addFinding(progress, 'note', `Note added: "${notes.slice(0, 80)}${notes.length > 80 ? '…' : ''}"`);
      update(next);
    }
  };

  return (
    <div className="w-[380px] flex-shrink-0 flex flex-col bg-white border-l border-gray-200 overflow-hidden">

      {/* ── Risk Score ───────────────────────────────────────────── */}
      <div className="px-4 pt-4 pb-3 border-b border-gray-100 flex-shrink-0">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] text-gray-400 uppercase tracking-widest font-medium">Entity Risk Score</span>
          <span className={`text-[10px] border px-2 py-0.5 rounded-full font-semibold ${
            riskScore >= 0.75 ? 'bg-red-100 text-red-700 border-red-200'
            : riskScore >= 0.55 ? 'bg-orange-100 text-orange-700 border-orange-200'
            : 'bg-green-100 text-green-700 border-green-200'
          }`}>
            {riskScore >= 0.75 ? 'HIGH' : riskScore >= 0.55 ? 'MODERATE' : 'LOW'}
          </span>
        </div>

        <div className="flex items-end gap-3 mb-2.5">
          <span className={`text-5xl font-thin leading-none tracking-tight ${
            riskScore >= 0.75 ? 'text-red-600' : riskScore >= 0.55 ? 'text-orange-500' : 'text-green-600'
          }`}>{riskScore.toFixed(2)}</span>
          <div className="flex-1 pb-1">
            <div className="relative h-2.5 rounded-full overflow-hidden" style={{
              background: 'linear-gradient(to right, #22c55e 0%, #eab308 45%, #f97316 70%, #ef4444 100%)',
            }}>
              <div className="absolute top-0 bottom-0 w-px bg-white/60" style={{ left: '50%' }} />
              <div
                className="absolute top-1/2 w-3.5 h-3.5 rounded-full bg-white border-2 shadow-md"
                style={{
                  left: `${riskScore * 100}%`,
                  transform: 'translate(-50%, -50%)',
                  borderColor: riskScore >= 0.75 ? '#ef4444' : riskScore >= 0.55 ? '#f97316' : '#22c55e',
                }}
              />
            </div>
            <div className="flex justify-between text-[9px] text-gray-400 mt-1 px-0.5">
              <span>Low</span>
              <span>Threshold 0.50</span>
              <span>Critical</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          {riskFactors.map(f => (
            <span key={f.name} className={`text-[10px] px-2 py-0.5 rounded-full border font-medium ${FACTOR_COLORS[f.category].badge}`}>
              {f.name}
            </span>
          ))}
        </div>
      </div>

      {/* ── Risk Factors ─────────────────────────────────────────── */}
      <div className="px-4 py-3 border-b border-gray-100 flex-shrink-0">
        <div className="text-[10px] text-gray-400 uppercase tracking-widest mb-2 font-medium">Risk Factors</div>
        <div className="space-y-1.5">
          {riskFactors.map((factor, i) => (
            <div key={factor.name} className="rounded-lg border border-gray-100 overflow-hidden">
              <div
                onClick={() => toggleFactor(i)}
                className="w-full flex items-center justify-between px-3 py-2 hover:bg-gray-50 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className={`w-2 h-2 rounded-full flex-shrink-0 ${FACTOR_COLORS[factor.category].dot}`} />
                  <span className="text-xs font-medium text-slate-700">{factor.name}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-[10px] text-gray-400">{factor.detectors} det.</span>
                  <span className="text-[10px] text-gray-400">{factor.ai} AI</span>
                  <span className="text-[10px] text-indigo-600 font-medium">
                    {expandedFactors.has(i) ? 'Less' : 'Examine'}
                  </span>
                  <ChevronDown size={12} className={`text-gray-400 transition-transform ${expandedFactors.has(i) ? 'rotate-180' : ''}`} />
                </div>
              </div>
              {expandedFactors.has(i) && (
                <div className={`px-3 py-2 text-[11px] leading-relaxed border-t border-gray-100 bg-gray-50/60 ${FACTOR_COLORS[factor.category].text}`}>
                  {factor.detail}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* ── Tabs ─────────────────────────────────────────────────── */}
      <div className="flex border-b border-gray-100 flex-shrink-0">
        {(['sar', 'trail'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-2 text-[11px] font-medium transition-colors border-b-2 ${
              activeTab === tab ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-gray-400 hover:text-gray-600'
            }`}
          >
            {tab === 'sar' ? 'SAR Analysis' : `Trail (${progress.findings.length})`}
          </button>
        ))}
      </div>

      {/* ── SAR Tab ──────────────────────────────────────────────── */}
      {activeTab === 'sar' && (
        <div className="flex-1 overflow-y-auto">
          <div className="px-4 py-3">
            <div className="text-[10px] text-gray-400 uppercase tracking-widest mb-2 font-medium">
              File a Suspicious Activity Report (SAR)
            </div>

            <div className="text-[11px] text-slate-600 leading-relaxed p-3 bg-amber-50/60 border border-amber-100 rounded-lg mb-3">
              {sarSummary}
            </div>

            {decision !== 'pending' && (
              <div className={`flex items-center gap-2 rounded-lg px-3 py-2.5 mb-3 text-[11px] font-medium ${
                decision === 'filed'     ? 'bg-green-50 text-green-700 border border-green-200' :
                decision === 'escalated' ? 'bg-red-50 text-red-700 border border-red-200'       :
                                           'bg-gray-100 text-gray-600 border border-gray-200'
              }`}>
                <CheckCircle size={13} />
                {decision === 'filed'     && 'SAR filed — case forwarded to FinCEN'}
                {decision === 'escalated' && 'Escalated to senior AML analyst'}
                {decision === 'cleared'   && 'Case cleared — no further action'}
              </div>
            )}

            <div className="flex gap-2 mb-3">
              <button
                onClick={() => handleDecision('filed')}
                disabled={decision !== 'pending'}
                className="flex-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-white text-[11px] py-2 px-3 rounded-lg transition-colors flex items-center justify-center gap-1.5 font-medium"
              >
                <FileText size={12} /> File SAR
              </button>
              <button
                onClick={() => handleDecision('escalated')}
                disabled={decision !== 'pending'}
                className="flex-1 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white text-[11px] py-2 px-3 rounded-lg transition-colors flex items-center justify-center gap-1.5 font-medium"
              >
                <ArrowUpCircle size={12} /> Escalate
              </button>
              <button
                onClick={() => handleDecision('cleared')}
                disabled={decision !== 'pending'}
                className="px-3 py-2 text-[11px] border border-gray-200 rounded-lg hover:bg-gray-50 disabled:opacity-50 transition-colors text-gray-600 font-medium"
              >
                Clear
              </button>
            </div>

            <div className="mb-3">
              <label className="text-[10px] text-gray-400 uppercase tracking-widest font-medium block mb-1.5">
                Review notes
              </label>
              <textarea
                value={notes}
                onChange={e => update({ notes: e.target.value })}
                onBlur={handleNotesBlur}
                placeholder="Add analyst notes or observations..."
                className="w-full border border-gray-200 rounded-lg p-2.5 text-[11px] resize-none h-16 focus:outline-none focus:ring-1 focus:ring-indigo-400 focus:border-indigo-400 placeholder:text-gray-400 bg-gray-50/60"
              />
            </div>

            <button
              disabled={decision === 'pending'}
              className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-200 disabled:text-gray-400 text-white py-2.5 px-4 rounded-lg text-[12px] font-semibold transition-colors"
            >
              {decision === 'pending' ? 'Record decision' : 'Decision recorded ✓'}
            </button>
          </div>
        </div>
      )}

      {/* ── Trail Tab ────────────────────────────────────────────── */}
      {activeTab === 'trail' && (
        <div className="flex-1 overflow-y-auto flex flex-col">
          <div className="flex items-center justify-between px-4 py-2 border-b border-gray-50 flex-shrink-0">
            <span className="text-[10px] text-gray-400 uppercase tracking-widest">Case log · {caseId}</span>
            <button
              onClick={() => exportLog(progress, caseId)}
              className="flex items-center gap-1 text-[10px] text-indigo-600 hover:text-indigo-800 transition-colors"
            >
              <Download size={10} /> Export log
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-0.5">
            {/* System recommendation */}
            <div className="flex gap-3 py-3 border-b border-gray-50">
              <div className="w-7 h-7 rounded-full bg-indigo-100 border border-indigo-200 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Cpu size={12} className="text-indigo-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="text-[11px] font-semibold text-slate-700">System recommendation</span>
                  <span className="text-[9px] bg-indigo-100 text-indigo-700 px-1.5 py-0.5 rounded-full font-semibold">auto</span>
                </div>
                <p className="text-[10px] text-gray-500 leading-relaxed mb-1">
                  {riskScore >= 0.50 ? `File SAR — risk score ${riskScore} exceeds 0.50 threshold. Detected: ${riskFactors.map(f => f.name).join(', ')}.`
                    : `No immediate SAR required — score ${riskScore} below threshold. Monitor for changes.`}
                </p>
                <span className="text-[9px] text-gray-400 flex items-center gap-1"><Clock size={9} /> On case load · automated</span>
              </div>
            </div>

            {/* Progress findings */}
            {[...progress.findings].reverse().map((entry, i) => (
              <div key={i} className="flex gap-3 py-3 border-b border-gray-50 last:border-0">
                <div className="w-7 h-7 rounded-full bg-gray-100 border border-gray-200 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <User size={12} className="text-gray-500" />
                </div>
                <div className="flex-1">
                  <div className="text-[10px] text-gray-500 leading-relaxed mb-0.5">{entry.content}</div>
                  <div className="flex items-center gap-1 text-[9px] text-gray-400">
                    <Clock size={9} />
                    <span>{new Date(entry.timestamp).toLocaleString()}</span>
                    <span>·</span>
                    <span>{entry.type.replace('_', ' ')}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
